import 'package:chat_app/models/firebaseHelper.dart';
import 'package:chat_app/models/user_model.dart';
import 'package:chat_app/presentation/pages/home_page.dart';
import 'package:chat_app/presentation/pages/login_page.dart';
import 'package:chat_app/presentation/pages/theme_provider.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';

Uuid uuid = const Uuid();
Future main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  User? currentUser = FirebaseAuth.instance.currentUser;
  if (currentUser != null) {
    UserModel? thisUserModel =
        await FirebaseHelper.getUserModelById(currentUser.uid);
    if (thisUserModel != null) {
      runApp(
        ChangeNotifierProvider(
          create: (context) => ThemeProvider(),
          child: MyAppLoggedIn(
              firebaseuser: currentUser, userModel: thisUserModel),
        ),
      );
    } else {
      runApp(
        ChangeNotifierProvider(
          create: (context) => ThemeProvider(),
          child: const MyApp(),
        ),
      );
    }
  } else {
    runApp(
      ChangeNotifierProvider(
        create: (context) => ThemeProvider(),
        child: const MyApp(),
      ),
    );
  }
}

var kSecondaryGradient = const LinearGradient(
  colors: [
    Color.fromARGB(255, 235, 138, 240),
    Color.fromARGB(255, 130, 12, 149),
  ],
);

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var themeProvider = Provider.of<ThemeProvider>(context);
    return ScreenUtilInit(
      builder: (context, child) => MaterialApp(
        debugShowCheckedModeBanner: false,
        home: const LoginPage(),
        theme: themeProvider.isDarkMode
            ? ThemeData.dark().copyWith(
                // Dark mode theme properties
                useMaterial3: true,
                colorScheme: ThemeData.dark().colorScheme.copyWith(
                      primary: const Color.fromARGB(255, 16, 66, 80),
                      secondary: const Color.fromARGB(255, 5, 99, 125),
                      onSecondary: Colors.white,
                      onPrimary: Colors.white,
                    ),
                cardTheme: const CardTheme().copyWith(
                  color: const Color.fromARGB(255, 5, 99, 125),
                  margin:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                ),
                elevatedButtonTheme: ElevatedButtonThemeData(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color.fromARGB(255, 5, 99, 125),
                    foregroundColor: Colors.white,
                  ),
                ),
                textTheme: ThemeData().textTheme.copyWith(
                      titleLarge: const TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                        fontSize: 17,
                      ),
                    ),
                primaryTextTheme: ThemeData().textTheme.copyWith(
                      titleLarge: const TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 20, 19, 19),
                        fontSize: 30,
                      ),
                    ),
                bottomNavigationBarTheme: const BottomNavigationBarThemeData(
                  backgroundColor: Color.fromARGB(255, 5, 99, 125),
                  selectedItemColor: Color.fromARGB(255, 91, 90, 90),
                  unselectedItemColor: Colors.grey,
                ),
              )
            : ThemeData.light().copyWith(
                // Light mode theme properties
                useMaterial3: true,
                colorScheme: ThemeData.light().colorScheme.copyWith(
                      primary: const Color.fromARGB(255, 165, 23, 172),
                      secondary: const Color.fromARGB(255, 122, 14, 116),
                      onSecondary: Colors.white,
                      onPrimary: Colors.white,
                    ),
                appBarTheme: const AppBarTheme().copyWith(
                  backgroundColor: const Color.fromARGB(255, 165, 23, 172),
                  foregroundColor: Colors.white,
                ),
                cardTheme: const CardTheme().copyWith(
                  color: Colors.grey[200],
                  margin:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                ),
                elevatedButtonTheme: ElevatedButtonThemeData(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color.fromARGB(255, 165, 23, 172),
                  ),
                ),
                textTheme: ThemeData().textTheme.copyWith(
                      titleLarge: const TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                        fontSize: 17,
                      ),
                    ),
                primaryTextTheme: ThemeData().textTheme.copyWith(
                      titleLarge: const TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                        fontSize: 30,
                      ),
                    ),
                bottomNavigationBarTheme: const BottomNavigationBarThemeData(
                  backgroundColor: Color.fromARGB(255, 122, 14, 116),
                  selectedItemColor: Colors.white,
                  unselectedItemColor: Colors.grey,
                ),
              ),
        themeMode: ThemeMode.system,
      ),
      designSize: const Size(411, 843),
    );
  }
}

class MyAppLoggedIn extends StatelessWidget {
  final User firebaseuser;
  final UserModel userModel;
  MyAppLoggedIn({required this.firebaseuser, required this.userModel});

  @override
  Widget build(BuildContext context) {
    var themeProvider = Provider.of<ThemeProvider>(context);
    return ScreenUtilInit(
      builder: (context, child) => MaterialApp(
        debugShowCheckedModeBanner: false,
        home: HomePage(firebaseUser: firebaseuser, userModel: userModel),
        theme: themeProvider.isDarkMode
            ? ThemeData.dark().copyWith(
                // Dark mode theme properties
                useMaterial3: true,
                colorScheme: ThemeData.dark().colorScheme.copyWith(
                      primary: const Color.fromARGB(255, 5, 99, 125),
                      // const Color.fromARGB(255, 16, 66, 80),
                      secondary: const Color.fromARGB(255, 5, 99, 125),
                      onSecondary: Colors.white,
                      onPrimary: Colors.white,
                    ),
                cardTheme: const CardTheme().copyWith(
                  color: const Color.fromARGB(255, 5, 99, 125),
                  margin:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                ),
                elevatedButtonTheme: ElevatedButtonThemeData(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color.fromARGB(255, 5, 99, 125),
                    foregroundColor: Colors.white,
                  ),
                ),
                textTheme: ThemeData().textTheme.copyWith(
                      titleLarge: const TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                        fontSize: 17,
                      ),
                    ),
                primaryTextTheme: ThemeData().textTheme.copyWith(
                      titleLarge: const TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 20, 19, 19),
                        fontSize: 30,
                      ),
                    ),
                bottomNavigationBarTheme: const BottomNavigationBarThemeData(
                  backgroundColor: Color.fromARGB(255, 5, 99, 125),
                  selectedItemColor: Color.fromARGB(255, 91, 90, 90),
                  unselectedItemColor: Colors.grey,
                ),
              )
            : ThemeData.light().copyWith(
                // Light mode theme properties
                useMaterial3: true,
                colorScheme: ThemeData.light().colorScheme.copyWith(
                      primary: const Color.fromARGB(255, 165, 23, 172),
                      secondary: const Color.fromARGB(255, 122, 14, 116),
                      onSecondary: Colors.white,
                      onPrimary: Colors.white,
                    ),
                appBarTheme: const AppBarTheme().copyWith(
                  backgroundColor: const Color.fromARGB(255, 165, 23, 172),
                  foregroundColor: Colors.white,
                ),
                cardTheme: const CardTheme().copyWith(
                  color: Colors.grey[200],
                  margin:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                ),
                elevatedButtonTheme: ElevatedButtonThemeData(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color.fromARGB(255, 165, 23, 172),
                  ),
                ),
                textTheme: ThemeData().textTheme.copyWith(
                      titleLarge: const TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                        fontSize: 17,
                      ),
                    ),
                primaryTextTheme: ThemeData().textTheme.copyWith(
                      titleLarge: const TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                        fontSize: 30,
                      ),
                    ),
                bottomNavigationBarTheme: const BottomNavigationBarThemeData(
                  backgroundColor: Color.fromARGB(255, 122, 14, 116),
                  selectedItemColor: Colors.white,
                  unselectedItemColor: Colors.grey,
                ),
              ),
        themeMode: ThemeMode.system,
      ),
    );
  }
}
