import 'package:chat_app/bloc/help_page_bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class HelpPage extends StatefulWidget {
  const HelpPage({Key? key}) : super(key: key);

  @override
  State<HelpPage> createState() => _HelpPageState();
}

class _HelpPageState extends State<HelpPage> {
  TextEditingController email = TextEditingController();
  TextEditingController message = TextEditingController();

  double responsiveSize(BuildContext context, double percentage) {
    return MediaQuery.of(context).size.width * percentage / 100.0;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Help"),
        backgroundColor: Theme.of(context).colorScheme.primary,
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            children: [
              SizedBox(height: 40.h),
              const Text(
                "Contact Us",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 40),
              ),
              SizedBox(height: 10.h),
              const Text("Get in touch, we'd love to hear from you"),
              SizedBox(height: 30.h),
              Card(
                elevation: 4.0,
                shape: RoundedRectangleBorder(
                  borderRadius:
                      BorderRadius.circular(responsiveSize(context, 12.0)),
                ),
                child: Padding(
                  padding: EdgeInsets.all(responsiveSize(context, 10)),
                  child: Column(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          color: Colors.grey[200],
                          border: Border.all(color: Colors.white),
                          borderRadius:
                              BorderRadius.circular(responsiveSize(context, 8)),
                        ),
                        child: Padding(
                          padding: EdgeInsets.only(
                              left: responsiveSize(context, 8.0)),
                          child: TextField(
                            controller: email,
                            decoration: const InputDecoration(
                              labelText: "Email Address",
                              border: InputBorder.none,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 10.h),
                      Container(
                        height: 200.h,
                        decoration: BoxDecoration(
                          color: Colors.grey[200],
                          border: Border.all(color: Colors.white),
                          borderRadius: BorderRadius.circular(
                              responsiveSize(context, 12)),
                        ),
                        child: Padding(
                          padding: EdgeInsets.only(
                              left: responsiveSize(context, 8.0)),
                          child: TextField(
                            controller: message,
                            decoration: const InputDecoration(
                              labelText: "Message",
                              border: InputBorder.none,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 20.h,
                      ),
                      GestureDetector(
                        onTap: () {
                          helpBloc.submitForm(email.text, message.text);
                          setState(() {
                            email.clear();
                            message.clear();
                          });
                          showDialog(
                            context: context,
                            builder: (BuildContext context) {
                              return AlertDialog(
                                title: Text(
                                  "Success",
                                  style: TextStyle(
                                    color:
                                        Theme.of(context).colorScheme.onPrimary,
                                  ),
                                ),
                                titleTextStyle: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20.sp,
                                ),
                                actions: [
                                  TextButton(
                                    child: Text(
                                      "OK",
                                      style: TextStyle(
                                        color: Theme.of(context)
                                            .colorScheme
                                            .onPrimary,
                                      ),
                                    ),
                                    onPressed: () {
                                      Navigator.pop(context);
                                    },
                                  ),
                                ],
                                backgroundColor:
                                    Theme.of(context).colorScheme.primary,
                                content: Text(
                                  "Sent successfully",
                                  style: TextStyle(
                                    color:
                                        Theme.of(context).colorScheme.onPrimary,
                                  ),
                                ),
                              );
                            },
                          );
                        },
                        child: Container(
                          width: 130.w,
                          height: 60.h,
                          padding: EdgeInsets.all(responsiveSize(context, 2)),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(
                                responsiveSize(context, 6)),
                            gradient: LinearGradient(
                              colors: [
                                Theme.of(context).colorScheme.secondary,
                                Theme.of(context).colorScheme.primary,
                              ],
                            ),
                          ),
                          child: Center(
                            child: Text(
                              "Send",
                              style: TextStyle(
                                fontSize: 20.sp,
                                fontWeight: FontWeight.bold,
                                color:
                                    Theme.of(context).colorScheme.onSecondary,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
