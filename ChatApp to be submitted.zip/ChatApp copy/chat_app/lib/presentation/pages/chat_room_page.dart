// import 'dart:developer';
// import 'package:chat_app/main.dart';
// import 'package:chat_app/models/chat_room_model.dart';
// import 'package:chat_app/models/message_model.dart';
// import 'package:chat_app/models/user_model.dart';
// import 'package:chat_app/presentation/pages/participant_detail.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:flutter/material.dart';

// class ChatRoomPage extends StatefulWidget {
//   final UserModel targetUser;
//   final ChatRoomModel chatroom;
//   final UserModel userModel;
//   final User firebaseUser;

//   const ChatRoomPage({
//     Key? key,
//     required this.targetUser,
//     required this.chatroom,
//     required this.userModel,
//     required this.firebaseUser,
//   }) : super(key: key);

//   @override
//   _ChatRoomPageState createState() => _ChatRoomPageState();
// }

// class _ChatRoomPageState extends State<ChatRoomPage> {
//   TextEditingController messageController = TextEditingController();

//   void sendMessage() async {
//     String msg = messageController.text.trim();
//     messageController.clear();

//     if (msg != "") {
//       // Send Message
//       MessageModel newMessage = MessageModel(
//         messageid: uuid.v1(),
//         sender: widget.userModel.uid,
//         createon: DateTime.now(),
//         text: msg,
//         seen: false,
//       );

//       FirebaseFirestore.instance
//           .collection("chatrooms")
//           .doc(widget.chatroom.chatroomid)
//           .collection("messages")
//           .doc(newMessage.messageid)
//           .set(newMessage.toMap());

//       widget.chatroom.lastMessage = msg;
//       FirebaseFirestore.instance
//           .collection("chatrooms")
//           .doc(widget.chatroom.chatroomid)
//           .set(widget.chatroom.toMap());

//       log("Message Sent!");
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         actions: [
//           const IconButton(
//             onPressed: null,
//             icon: Icon(Icons.call),
//           ),
//           const IconButton(
//             onPressed: null,
//             icon: Icon(Icons.video_call_rounded),
//           ),
//           PopupMenuButton(
//             itemBuilder: (context) {
//               return const [
//                 PopupMenuItem(child: Text("View Contact"), value: 1),
//                 PopupMenuItem(child: Text("Mute Notifications"), value: 2),
//                 PopupMenuItem(child: Text("Disappearing Messages"), value: 3),
//               ];
//             },
//             onSelected: (value) {
//               if (value == 1) {
//                 Navigator.push(
//                   context,
//                   MaterialPageRoute(
//                     builder: (context) {
//                       return ParticipantDetail(
//                         userModel: widget.userModel,
//                         firebaseUser: widget.firebaseUser,
//                         targetUser: widget.targetUser,
//                         chatroom: widget.chatroom,
//                       );
//                     },
//                   ),
//                 );
//               }
//             },
//           )
//         ],
//         backgroundColor: Theme.of(context).colorScheme.primary,
//         title: GestureDetector(
//           onTap: () {
//             Navigator.push(context, MaterialPageRoute(builder: (context) {
//               return ParticipantDetail(
//                 userModel: widget.userModel,
//                 firebaseUser: widget.firebaseUser,
//                 targetUser: widget.targetUser,
//                 chatroom: widget.chatroom,
//               );
//             }));
//           },
//           child: Container(
//             child: Row(
//               children: [
//                 CircleAvatar(
//                   backgroundColor:
//                       Theme.of(context).colorScheme.primaryContainer,
//                   backgroundImage:
//                       NetworkImage(widget.targetUser.profilePic.toString()),
//                 ),
//                 const SizedBox(
//                   width: 5,
//                 ),
//                 Text(widget.targetUser.fullname.toString()),
//               ],
//             ),
//           ),
//         ),
//       ),
//       body: SafeArea(
//         child: Container(
//           child: Column(
//             children: [
//               Expanded(
//                 child: Container(
//                   padding: const EdgeInsets.symmetric(horizontal: 10),
//                   child: StreamBuilder(
//                     stream: FirebaseFirestore.instance
//                         .collection("chatrooms")
//                         .doc(widget.chatroom.chatroomid)
//                         .collection("messages")
//                         .orderBy("createon", descending: true)
//                         .snapshots(),
//                     builder: (context, snapshot) {
//                       if (snapshot.connectionState == ConnectionState.active) {
//                         if (snapshot.hasData) {
//                           QuerySnapshot dataSnapshot =
//                               snapshot.data as QuerySnapshot;

//                           return ListView.builder(
//                             reverse: true,
//                             itemCount: dataSnapshot.docs.length,
//                             itemBuilder: (context, index) {
//                               MessageModel currentMessage =
//                                   MessageModel.fromMap(dataSnapshot.docs[index]
//                                       .data() as Map<String, dynamic>);

//                               return Row(
//                                 mainAxisAlignment: (currentMessage.sender ==
//                                         widget.userModel.uid)
//                                     ? MainAxisAlignment.end
//                                     : MainAxisAlignment.start,
//                                 children: [
//                                   Flexible(
//                                     child: Container(
//                                       margin: const EdgeInsets.symmetric(
//                                           vertical: 2, horizontal: 5),
//                                       padding: const EdgeInsets.symmetric(
//                                         vertical: 10,
//                                         horizontal: 10,
//                                       ),
//                                       decoration: BoxDecoration(
//                                         gradient: (currentMessage.sender ==
//                                                 widget.userModel.uid)
//                                             ? kSecondaryGradient
//                                             : const LinearGradient(colors: [
//                                                 Color.fromARGB(255, 76, 74, 74),
//                                                 Color.fromARGB(
//                                                     255, 168, 159, 159)
//                                               ]),
//                                         color: (currentMessage.sender !=
//                                                 widget.userModel.uid)
//                                             ? Colors.grey
//                                             : null,
//                                         borderRadius: (currentMessage.sender ==
//                                                 widget.userModel.uid)
//                                             ? const BorderRadius.only(
//                                                 topLeft: Radius.circular(10),
//                                                 topRight: Radius.circular(10),
//                                                 bottomLeft: Radius.circular(10),
//                                               )
//                                             : const BorderRadius.only(
//                                                 bottomLeft: Radius.circular(10),
//                                                 topRight: Radius.circular(10),
//                                                 bottomRight:
//                                                     Radius.circular(10),
//                                               ),
//                                       ),
//                                       child: Text(
//                                         currentMessage.text.toString(),
//                                         style: const TextStyle(
//                                           fontSize: 18,
//                                           color: Colors.white,
//                                         ),
//                                         overflow: TextOverflow.ellipsis,
//                                       ),
//                                     ),
//                                   ),
//                                 ],
//                               );
//                             },
//                           );
//                         } else if (snapshot.hasError) {
//                           return const Center(
//                             child: Text(
//                               "An error occurred! Please check your internet connection.",
//                             ),
//                           );
//                         } else {
//                           return const Center(
//                             child: Text("Say hi to your new friend"),
//                           );
//                         }
//                       } else {
//                         return Center(
//                           child: CircularProgressIndicator(
//                             color: Theme.of(context).colorScheme.primary,
//                           ),
//                         );
//                       }
//                     },
//                   ),
//                 ),
//               ),
//               const SizedBox(
//                 height: 10,
//               ),
//               Row(
//                 children: [
//                   Container(
//                     width: MediaQuery.of(context).size.width * 0.75,
//                     decoration: BoxDecoration(
//                       borderRadius: BorderRadius.circular(30),
//                       color: Theme.of(context).colorScheme.primary,
//                     ),
//                     margin: const EdgeInsets.symmetric(
//                         horizontal: 15, vertical: 15),
//                     padding:
//                         const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
//                     child: Row(
//                       children: [
//                         Flexible(
//                           child: TextField(
//                             controller: messageController,
//                             maxLines: null,
//                             decoration: InputDecoration(
//                                 border: InputBorder.none,
//                                 hintText: "Enter message",
//                                 hintStyle: TextStyle(
//                                   color: Theme.of(context)
//                                       .colorScheme
//                                       .onPrimaryContainer,
//                                 )),
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                   Container(
//                     decoration: BoxDecoration(
//                       borderRadius: BorderRadius.circular(30),
//                       color: Theme.of(context).colorScheme.primary,
//                     ),
//                     child: IconButton(
//                       onPressed: () {
//                         sendMessage();
//                       },
//                       icon: Icon(
//                         Icons.send,
//                         color: Theme.of(context).colorScheme.onPrimaryContainer,
//                       ),
//                     ),
//                   ),
//                 ],
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
// import 'dart:developer';
// import 'package:chat_app/main.dart';
// import 'package:chat_app/models/chat_room_model.dart';
// import 'package:chat_app/models/message_model.dart';
// import 'package:chat_app/models/user_model.dart';
// import 'package:chat_app/presentation/pages/participant_detail.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:flutter/material.dart';
// import 'package:emoji_picker_flutter/emoji_picker_flutter.dart';

// class ChatRoomPage extends StatefulWidget {
//   final UserModel targetUser;
//   final ChatRoomModel chatroom;
//   final UserModel userModel;
//   final User firebaseUser;

//   const ChatRoomPage({
//     Key? key,
//     required this.targetUser,
//     required this.chatroom,
//     required this.userModel,
//     required this.firebaseUser,
//   }) : super(key: key);

//   @override
//   _ChatRoomPageState createState() => _ChatRoomPageState();
// }

// class _ChatRoomPageState extends State<ChatRoomPage> {
//   TextEditingController messageController = TextEditingController();
//   ScrollController _scrollController = ScrollController();

//   void sendMessage() async {
//     String msg = messageController.text.trim();
//     messageController.clear();

//     if (msg != "") {
//       MessageModel newMessage = MessageModel(
//         messageid: uuid.v1(),
//         sender: widget.userModel.uid,
//         createon: DateTime.now(),
//         text: msg,
//         seen: false,
//       );

//       FirebaseFirestore.instance
//           .collection("chatrooms")
//           .doc(widget.chatroom.chatroomid)
//           .collection("messages")
//           .doc(newMessage.messageid)
//           .set(newMessage.toMap());

//       widget.chatroom.lastMessage = msg;
//       FirebaseFirestore.instance
//           .collection("chatrooms")
//           .doc(widget.chatroom.chatroomid)
//           .set(widget.chatroom.toMap());

//       log("Message Sent!");

//       _scrollController.animateTo(
//         0.0,
//         curve: Curves.easeOut,
//         duration: const Duration(milliseconds: 300),
//       );
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         actions: [
//           const IconButton(
//             onPressed: null,
//             icon: Icon(Icons.call),
//           ),
//           const IconButton(
//             onPressed: null,
//             icon: Icon(Icons.video_call_rounded),
//           ),
//           PopupMenuButton(
//             itemBuilder: (context) {
//               return const [
//                 PopupMenuItem(child: Text("View Contact"), value: 1),
//                 PopupMenuItem(child: Text("Mute Notifications"), value: 2),
//                 PopupMenuItem(child: Text("Disappearing Messages"), value: 3),
//               ];
//             },
//             onSelected: (value) {
//               if (value == 1) {
//                 Navigator.push(
//                   context,
//                   MaterialPageRoute(
//                     builder: (context) {
//                       return ParticipantDetail(
//                         userModel: widget.userModel,
//                         firebaseUser: widget.firebaseUser,
//                         targetUser: widget.targetUser,
//                         chatroom: widget.chatroom,
//                       );
//                     },
//                   ),
//                 );
//               }
//             },
//           )
//         ],
//         backgroundColor: Theme.of(context).colorScheme.primary,
//         title: GestureDetector(
//           onTap: () {
//             Navigator.push(context, MaterialPageRoute(builder: (context) {
//               return ParticipantDetail(
//                 userModel: widget.userModel,
//                 firebaseUser: widget.firebaseUser,
//                 targetUser: widget.targetUser,
//                 chatroom: widget.chatroom,
//               );
//             }));
//           },
//           child: Container(
//             child: Row(
//               children: [
//                 CircleAvatar(
//                   backgroundColor:
//                       Theme.of(context).colorScheme.primaryContainer,
//                   backgroundImage:
//                       NetworkImage(widget.targetUser.profilePic.toString()),
//                 ),
//                 const SizedBox(
//                   width: 5,
//                 ),
//                 Text(widget.targetUser.fullname.toString()),
//               ],
//             ),
//           ),
//         ),
//       ),
//       body: SafeArea(
//         child: Container(
//           child: Column(
//             children: [
//               Expanded(
//                 child: StreamBuilder(
//                   stream: FirebaseFirestore.instance
//                       .collection("chatrooms")
//                       .doc(widget.chatroom.chatroomid)
//                       .collection("messages")
//                       .orderBy("createon", descending: true)
//                       .snapshots(),
//                   builder: (context, snapshot) {
//                     if (snapshot.connectionState == ConnectionState.active) {
//                       if (snapshot.hasData) {
//                         return ListView.builder(
//                           reverse: true,
//                           controller: _scrollController,
//                           itemCount:
//                               (snapshot.data as QuerySnapshot).docs.length,
//                           itemBuilder: (context, index) {
//                             MessageModel currentMessage = MessageModel.fromMap(
//                               (snapshot.data as QuerySnapshot)
//                                   .docs[index]
//                                   .data() as Map<String, dynamic>,
//                             );

//                             return Row(
//                               mainAxisAlignment: (currentMessage.sender ==
//                                       widget.userModel.uid)
//                                   ? MainAxisAlignment.end
//                                   : MainAxisAlignment.start,
//                               children: [
//                                 Expanded(
//                                   child: Container(
//                                     margin: const EdgeInsets.symmetric(
//                                         vertical: 2, horizontal: 5),
//                                     padding: const EdgeInsets.symmetric(
//                                       vertical: 10,
//                                       horizontal: 10,
//                                     ),
//                                     decoration: BoxDecoration(
//                                       gradient: (currentMessage.sender ==
//                                               widget.userModel.uid)
//                                           ? kSecondaryGradient
//                                           : const LinearGradient(
//                                               colors: [
//                                                 Color.fromARGB(255, 76, 74, 74),
//                                                 Color.fromARGB(
//                                                     255, 168, 159, 159)
//                                               ],
//                                             ),
//                                       color: (currentMessage.sender !=
//                                               widget.userModel.uid)
//                                           ? Colors.grey
//                                           : null,
//                                       borderRadius: (currentMessage.sender ==
//                                               widget.userModel.uid)
//                                           ? const BorderRadius.only(
//                                               topLeft: Radius.circular(10),
//                                               topRight: Radius.circular(10),
//                                               bottomLeft: Radius.circular(10),
//                                             )
//                                           : const BorderRadius.only(
//                                               bottomLeft: Radius.circular(10),
//                                               topRight: Radius.circular(10),
//                                               bottomRight: Radius.circular(10),
//                                             ),
//                                     ),

//                                     child: Text(
//                                       currentMessage.text.toString(),
//                                       style: const TextStyle(
//                                         fontSize: 18,
//                                         color: Colors.white,
//                                       ),
//                                       textAlign: (currentMessage.sender ==
//                                               widget.userModel.uid)
//                                           ? TextAlign.end
//                                           : TextAlign.start,
//                                       softWrap: true,
//                                     ),
//                                   ),
//                                 ),
//                               ],
//                             );
//                           },
//                         );
//                       } else if (snapshot.hasError) {
//                         return const Center(
//                           child: Text(
//                             "An error occurred! Please check your internet connection.",
//                           ),
//                         );
//                       } else {
//                         return const Center(
//                           child: Text("Say hi to your new friend"),
//                         );
//                       }
//                     } else {
//                       return Center(
//                         child: CircularProgressIndicator(
//                           color: Theme.of(context).colorScheme.primary,
//                         ),
//                       );
//                     }
//                   },
//                 ),
//               ),
//               const SizedBox(
//                 height: 10,
//               ),
//               Row(
//                 children: [
//                   Container(
//                     width: MediaQuery.of(context).size.width * 0.75,
//                     decoration: BoxDecoration(
//                       borderRadius: BorderRadius.circular(30),
//                       color: Theme.of(context).colorScheme.primary,
//                     ),
//                     margin: const EdgeInsets.symmetric(
//                         horizontal: 15, vertical: 15),
//                     padding:
//                         const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
//                     child: Row(
//                       children: [
//                         Flexible(
//                           child: TextField(
//                             controller: messageController,
//                             maxLines: null,
//                             decoration: InputDecoration(
//                               border: InputBorder.none,
//                               hintText: "Enter message",
//                               hintStyle: TextStyle(
//                                 color: Theme.of(context)
//                                     .colorScheme
//                                     .onPrimaryContainer,
//                               ),
//                             ),
//                           ),
//                         ),
//                         IconButton(
//                           onPressed: () async {
//                             // Open emoji picker
//                             await showModalBottomSheet(
//                               context: context,
//                               builder: (BuildContext context) {
//                                 return EmojiPicker(
//                                   onEmojiSelected: (category, emoji) {
//                                     setState(() {
//                                       messageController.text += emoji.emoji;
//                                     });
//                                   },
//                                   onBackspacePressed: () {
//                                     setState(() {
//                                       messageController.text = messageController
//                                           .text.characters
//                                           .skipLast(1)
//                                           .toString();
//                                     });
//                                   },
//                                   config: const Config(
//                                     columns: 7,
//                                     emojiSizeMax: 32.0,
//                                     verticalSpacing: 0,
//                                     horizontalSpacing: 0,
//                                     initCategory: Category.SMILEYS,
//                                   ),
//                                 );
//                               },
//                             );
//                           },
//                           icon: Icon(
//                             Icons.emoji_emotions,
//                             color: Theme.of(context)
//                                 .colorScheme
//                                 .onPrimaryContainer,
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                   Container(
//                     decoration: BoxDecoration(
//                       borderRadius: BorderRadius.circular(30),
//                       color: Theme.of(context).colorScheme.primary,
//                     ),
//                     child: IconButton(
//                       onPressed: () {
//                         sendMessage();
//                       },
//                       icon: Icon(
//                         Icons.send,
//                         color: Theme.of(context).colorScheme.onPrimaryContainer,
//                       ),
//                     ),
//                   ),
//                 ],
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }

// import 'dart:developer';
// import 'package:chat_app/main.dart';
// import 'package:chat_app/models/chat_room_model.dart';
// import 'package:chat_app/models/message_model.dart';
// import 'package:chat_app/models/user_model.dart';
// import 'package:chat_app/presentation/pages/participant_detail.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:flutter/material.dart';
// import 'package:emoji_picker_flutter/emoji_picker_flutter.dart';

// class ChatRoomPage extends StatefulWidget {
//   final UserModel targetUser;
//   final ChatRoomModel chatroom;
//   final UserModel userModel;
//   final User firebaseUser;

//   const ChatRoomPage({
//     Key? key,
//     required this.targetUser,
//     required this.chatroom,
//     required this.userModel,
//     required this.firebaseUser,
//   }) : super(key: key);

//   @override
//   _ChatRoomPageState createState() => _ChatRoomPageState();
// }

// class _ChatRoomPageState extends State<ChatRoomPage> {
//   TextEditingController messageController = TextEditingController();
//   ScrollController _scrollController = ScrollController();

//   void sendMessage() async {
//     String msg = messageController.text.trim();
//     messageController.clear();

//     if (msg != "") {
//       MessageModel newMessage = MessageModel(
//         messageid: uuid.v1(),
//         sender: widget.userModel.uid,
//         createon: DateTime.now(),
//         text: msg,
//         seen: false,
//       );

//       FirebaseFirestore.instance
//           .collection("chatrooms")
//           .doc(widget.chatroom.chatroomid)
//           .collection("messages")
//           .doc(newMessage.messageid)
//           .set(newMessage.toMap());

//       widget.chatroom.lastMessage = msg;
//       FirebaseFirestore.instance
//           .collection("chatrooms")
//           .doc(widget.chatroom.chatroomid)
//           .set(widget.chatroom.toMap());

//       log("Message Sent!");

//       _scrollController.animateTo(
//         0.0,
//         curve: Curves.easeOut,
//         duration: const Duration(milliseconds: 300),
//       );
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         actions: [
//           const IconButton(
//             onPressed: null,
//             icon: Icon(Icons.call),
//           ),
//           const IconButton(
//             onPressed: null,
//             icon: Icon(Icons.video_call_rounded),
//           ),
//           PopupMenuButton(
//             itemBuilder: (context) {
//               return const [
//                 PopupMenuItem(child: Text("View Contact"), value: 1),
//                 PopupMenuItem(child: Text("Mute Notifications"), value: 2),
//                 PopupMenuItem(child: Text("Disappearing Messages"), value: 3),
//               ];
//             },
//             onSelected: (value) {
//               if (value == 1) {
//                 Navigator.push(
//                   context,
//                   MaterialPageRoute(
//                     builder: (context) {
//                       return ParticipantDetail(
//                         userModel: widget.userModel,
//                         firebaseUser: widget.firebaseUser,
//                         targetUser: widget.targetUser,
//                         chatroom: widget.chatroom,
//                       );
//                     },
//                   ),
//                 );
//               }
//             },
//           )
//         ],
//         backgroundColor: Theme.of(context).colorScheme.primary,
//         title: GestureDetector(
//           onTap: () {
//             Navigator.push(context, MaterialPageRoute(builder: (context) {
//               return ParticipantDetail(
//                 userModel: widget.userModel,
//                 firebaseUser: widget.firebaseUser,
//                 targetUser: widget.targetUser,
//                 chatroom: widget.chatroom,
//               );
//             }));
//           },
//           child: Container(
//             child: Row(
//               children: [
//                 CircleAvatar(
//                   backgroundColor:
//                       Theme.of(context).colorScheme.primaryContainer,
//                   backgroundImage:
//                       NetworkImage(widget.targetUser.profilePic.toString()),
//                 ),
//                 const SizedBox(
//                   width: 5,
//                 ),
//                 Text(widget.targetUser.fullname.toString()),
//               ],
//             ),
//           ),
//         ),
//       ),
//       body: SafeArea(
//         child: Container(
//           child: Column(
//             children: [
//               Expanded(
//                 child: StreamBuilder(
//                   stream: FirebaseFirestore.instance
//                       .collection("chatrooms")
//                       .doc(widget.chatroom.chatroomid)
//                       .collection("messages")
//                       .orderBy("createon", descending: true)
//                       .snapshots(),
//                   builder: (context, snapshot) {
//                     if (snapshot.connectionState == ConnectionState.active) {
//                       if (snapshot.hasData) {
//                         return ListView.builder(
//                           reverse: true,
//                           controller: _scrollController,
//                           itemCount:
//                               (snapshot.data as QuerySnapshot).docs.length,
//                           itemBuilder: (context, index) {
//                             MessageModel currentMessage = MessageModel.fromMap(
//                               (snapshot.data as QuerySnapshot)
//                                   .docs[index]
//                                   .data() as Map<String, dynamic>,
//                             );

//                             return Row(
//                               mainAxisAlignment: (currentMessage.sender ==
//                                       widget.userModel.uid)
//                                   ? MainAxisAlignment.end
//                                   : MainAxisAlignment.start,
//                               children: [
//                                 Container(
//                                   margin: const EdgeInsets.symmetric(
//                                       vertical: 2, horizontal: 5),
//                                   constraints: BoxConstraints(
//                                     maxWidth: MediaQuery.of(context)
//                                             .size
//                                             .width *
//                                         0.7, // Adjust the percentage as needed
//                                   ),
//                                   padding: const EdgeInsets.symmetric(
//                                     vertical: 10,
//                                     horizontal: 10,
//                                   ),
//                                   decoration: BoxDecoration(
//                                     gradient: (currentMessage.sender ==
//                                             widget.userModel.uid)
//                                         ? kSecondaryGradient
//                                         : const LinearGradient(
//                                             colors: [
//                                               Color.fromARGB(255, 76, 74, 74),
//                                               Color.fromARGB(255, 168, 159, 159)
//                                             ],
//                                           ),
//                                     color: (currentMessage.sender !=
//                                             widget.userModel.uid)
//                                         ? Colors.grey
//                                         : null,
//                                     borderRadius: (currentMessage.sender ==
//                                             widget.userModel.uid)
//                                         ? const BorderRadius.only(
//                                             topLeft: Radius.circular(10),
//                                             topRight: Radius.circular(10),
//                                             bottomLeft: Radius.circular(10),
//                                           )
//                                         : const BorderRadius.only(
//                                             bottomLeft: Radius.circular(10),
//                                             topRight: Radius.circular(10),
//                                             bottomRight: Radius.circular(10),
//                                           ),
//                                   ),
//                                   child: Text(
//                                     currentMessage.text.toString(),
//                                     style: const TextStyle(
//                                       fontSize: 18,
//                                       color: Colors.white,
//                                     ),
//                                     textAlign: (currentMessage.sender ==
//                                             widget.userModel.uid)
//                                         ? TextAlign.end
//                                         : TextAlign.start,
//                                     softWrap: true,
//                                   ),
//                                 ),
//                               ],
//                             );
//                           },
//                         );
//                       } else if (snapshot.hasError) {
//                         return const Center(
//                           child: Text(
//                             "An error occurred! Please check your internet connection.",
//                           ),
//                         );
//                       } else {
//                         return const Center(
//                           child: Text("Say hi to your new friend"),
//                         );
//                       }
//                     } else {
//                       return Center(
//                         child: CircularProgressIndicator(
//                           color: Theme.of(context).colorScheme.primary,
//                         ),
//                       );
//                     }
//                   },
//                 ),
//               ),
//               const SizedBox(
//                 height: 10,
//               ),
//               Row(
//                 children: [
//                   Container(
//                     width: MediaQuery.of(context).size.width * 0.75,
//                     decoration: BoxDecoration(
//                       borderRadius: BorderRadius.circular(30),
//                       color: Theme.of(context).colorScheme.primary,
//                     ),
//                     margin: const EdgeInsets.symmetric(
//                         horizontal: 15, vertical: 15),
//                     padding:
//                         const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
//                     child: Row(
//                       children: [
//                         Flexible(
//                           child: TextField(
//                             controller: messageController,
//                             maxLines: null,
//                             decoration: InputDecoration(
//                               border: InputBorder.none,
//                               hintText: "Enter message",
//                               hintStyle: TextStyle(
//                                 color: Theme.of(context)
//                                     .colorScheme
//                                     .onPrimaryContainer,
//                               ),
//                             ),
//                           ),
//                         ),
//                         IconButton(
//                           onPressed: () async {
//                             // Open emoji picker
//                             await showModalBottomSheet(
//                               context: context,
//                               builder: (BuildContext context) {
//                                 return EmojiPicker(
//                                   onEmojiSelected: (category, emoji) {
//                                     setState(() {
//                                       messageController.text += emoji.emoji;
//                                     });
//                                   },
//                                   onBackspacePressed: () {
//                                     setState(() {
//                                       messageController.text = messageController
//                                           .text.characters
//                                           .skipLast(1)
//                                           .toString();
//                                     });
//                                   },
//                                   config: const Config(
//                                     columns: 7,
//                                     emojiSizeMax: 32.0,
//                                     verticalSpacing: 0,
//                                     horizontalSpacing: 0,
//                                     initCategory: Category.SMILEYS,
//                                   ),
//                                 );
//                               },
//                             );
//                           },
//                           icon: Icon(
//                             Icons.emoji_emotions,
//                             color: Theme.of(context)
//                                 .colorScheme
//                                 .onPrimaryContainer,
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                   Container(
//                     decoration: BoxDecoration(
//                       borderRadius: BorderRadius.circular(30),
//                       color: Theme.of(context).colorScheme.primary,
//                     ),
//                     child: IconButton(
//                       onPressed: () {
//                         sendMessage();
//                       },
//                       icon: Icon(
//                         Icons.send,
//                         color: Theme.of(context).colorScheme.onPrimaryContainer,
//                       ),
//                     ),
//                   ),
//                 ],
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }

import 'dart:developer';
import 'package:chat_app/main.dart';
import 'package:chat_app/models/chat_room_model.dart';
import 'package:chat_app/models/message_model.dart';
import 'package:chat_app/models/user_model.dart';
import 'package:chat_app/presentation/pages/participant_detail.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:emoji_picker_flutter/emoji_picker_flutter.dart';

class ChatRoomPage extends StatefulWidget {
  final UserModel targetUser;
  final ChatRoomModel chatroom;
  final UserModel userModel;
  final User firebaseUser;

  const ChatRoomPage({
    Key? key,
    required this.targetUser,
    required this.chatroom,
    required this.userModel,
    required this.firebaseUser,
  }) : super(key: key);

  @override
  _ChatRoomPageState createState() => _ChatRoomPageState();
}

class _ChatRoomPageState extends State<ChatRoomPage> {
  TextEditingController messageController = TextEditingController();
  ScrollController _scrollController = ScrollController();

  void sendMessage() async {
    String msg = messageController.text.trim();
    messageController.clear();

    if (msg != "") {
      MessageModel newMessage = MessageModel(
        messageid: uuid.v1(),
        sender: widget.userModel.uid,
        createon: DateTime.now(),
        text: msg,
        seen: false,
      );

      FirebaseFirestore.instance
          .collection("chatrooms")
          .doc(widget.chatroom.chatroomid)
          .collection("messages")
          .doc(newMessage.messageid)
          .set(newMessage.toMap());

      widget.chatroom.lastMessage = msg;
      FirebaseFirestore.instance
          .collection("chatrooms")
          .doc(widget.chatroom.chatroomid)
          .set(widget.chatroom.toMap());

      log("Message Sent!");

      _scrollController.animateTo(
        0.0,
        curve: Curves.easeOut,
        duration: const Duration(milliseconds: 300),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: [
          const IconButton(
            onPressed: null,
            icon: Icon(Icons.call),
          ),
          const IconButton(
            onPressed: null,
            icon: Icon(Icons.video_call_rounded),
          ),
          PopupMenuButton(
            itemBuilder: (context) {
              return const [
                PopupMenuItem(child: Text("View Contact"), value: 1),
                PopupMenuItem(child: Text("Mute Notifications"), value: 2),
                PopupMenuItem(child: Text("Disappearing Messages"), value: 3),
              ];
            },
            onSelected: (value) {
              if (value == 1) {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) {
                      return ParticipantDetail(
                        userModel: widget.userModel,
                        firebaseUser: widget.firebaseUser,
                        targetUser: widget.targetUser,
                        chatroom: widget.chatroom,
                      );
                    },
                  ),
                );
              }
            },
          )
        ],
        backgroundColor: Theme.of(context).colorScheme.primary,
        title: GestureDetector(
          onTap: () {
            Navigator.push(context, MaterialPageRoute(builder: (context) {
              return ParticipantDetail(
                userModel: widget.userModel,
                firebaseUser: widget.firebaseUser,
                targetUser: widget.targetUser,
                chatroom: widget.chatroom,
              );
            }));
          },
          child: Container(
            child: Row(
              children: [
                CircleAvatar(
                  backgroundColor:
                      Theme.of(context).colorScheme.primaryContainer,
                  backgroundImage:
                      NetworkImage(widget.targetUser.profilePic.toString()),
                ),
                const SizedBox(
                  width: 5,
                ),
                Text(widget.targetUser.fullname.toString()),
              ],
            ),
          ),
        ),
      ),
      body: SafeArea(
        child: Container(
          child: Column(
            children: [
              Expanded(
                child: StreamBuilder(
                  stream: FirebaseFirestore.instance
                      .collection("chatrooms")
                      .doc(widget.chatroom.chatroomid)
                      .collection("messages")
                      .orderBy("createon", descending: true)
                      .snapshots(),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.active) {
                      if (snapshot.hasData) {
                        return ListView.builder(
                          reverse: true,
                          controller: _scrollController,
                          itemCount:
                              (snapshot.data as QuerySnapshot).docs.length,
                          itemBuilder: (context, index) {
                            MessageModel currentMessage = MessageModel.fromMap(
                              (snapshot.data as QuerySnapshot)
                                  .docs[index]
                                  .data() as Map<String, dynamic>,
                            );

                            return LongPressDraggable(
                              onDragEnd: (details) {
                                // Handle drag end
                              },
                              onDragStarted: () {
                                // Handle drag start
                              },
                              feedback: Container(
                                // Customize the appearance of the feedback
                                child: Text("Drag me"),
                              ),
                              data: currentMessage,
                              childWhenDragging:
                                  Container(), // Widget to show when dragging
                              child: GestureDetector(
                                onLongPress: () {
                                  // Show options for sharing the message
                                  showModalBottomSheet(
                                    context: context,
                                    builder: (BuildContext context) {
                                      return Column(
                                        mainAxisSize: MainAxisSize.min,
                                        children: <Widget>[
                                          ListTile(
                                            leading: Icon(Icons.share),
                                            title: Text('Share'),
                                            onTap: () {
                                              // Implement your logic for sharing the message
                                              Navigator.pop(context);
                                            },
                                          ),
                                          // Add more options as needed
                                        ],
                                      );
                                    },
                                  );
                                },
                                child: Row(
                                  mainAxisAlignment: (currentMessage.sender ==
                                          widget.userModel.uid)
                                      ? MainAxisAlignment.end
                                      : MainAxisAlignment.start,
                                  children: [
                                    Container(
                                      margin: const EdgeInsets.symmetric(
                                          vertical: 2, horizontal: 5),
                                      constraints: BoxConstraints(
                                        maxWidth:
                                            MediaQuery.of(context).size.width *
                                                0.7,
                                      ),
                                      padding: const EdgeInsets.symmetric(
                                        vertical: 10,
                                        horizontal: 10,
                                      ),
                                      decoration: BoxDecoration(
                                        gradient: (currentMessage.sender ==
                                                widget.userModel.uid)
                                            ? kSecondaryGradient
                                            : const LinearGradient(
                                                colors: [
                                                  Color.fromARGB(
                                                      255, 76, 74, 74),
                                                  Color.fromARGB(
                                                      255, 168, 159, 159)
                                                ],
                                              ),
                                        color: (currentMessage.sender !=
                                                widget.userModel.uid)
                                            ? Colors.grey
                                            : null,
                                        borderRadius: (currentMessage.sender ==
                                                widget.userModel.uid)
                                            ? const BorderRadius.only(
                                                topLeft: Radius.circular(10),
                                                topRight: Radius.circular(10),
                                                bottomLeft: Radius.circular(10),
                                              )
                                            : const BorderRadius.only(
                                                bottomLeft: Radius.circular(10),
                                                topRight: Radius.circular(10),
                                                bottomRight:
                                                    Radius.circular(10),
                                              ),
                                      ),
                                      child: Text(
                                        currentMessage.text.toString(),
                                        style: const TextStyle(
                                          fontSize: 18,
                                          color: Colors.white,
                                        ),
                                        textAlign: (currentMessage.sender ==
                                                widget.userModel.uid)
                                            ? TextAlign.end
                                            : TextAlign.start,
                                        softWrap: true,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        );
                      } else if (snapshot.hasError) {
                        return const Center(
                          child: Text(
                            "An error occurred! Please check your internet connection.",
                          ),
                        );
                      } else {
                        return const Center(
                          child: Text("Say hi to your new friend"),
                        );
                      }
                    } else {
                      return Center(
                        child: CircularProgressIndicator(
                          color: Theme.of(context).colorScheme.primary,
                        ),
                      );
                    }
                  },
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              Row(
                children: [
                  Container(
                    width: MediaQuery.of(context).size.width * 0.75,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(30),
                      color: Theme.of(context).colorScheme.primary,
                    ),
                    margin: const EdgeInsets.symmetric(
                        horizontal: 15, vertical: 15),
                    padding:
                        const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
                    child: Row(
                      children: [
                        Flexible(
                          child: TextField(
                            controller: messageController,
                            maxLines: null,
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              hintText: "Enter message",
                              hintStyle: TextStyle(
                                color: Theme.of(context)
                                    .colorScheme
                                    .onPrimaryContainer,
                              ),
                            ),
                          ),
                        ),
                        IconButton(
                          onPressed: () async {
                            // Open emoji picker
                            await showModalBottomSheet(
                              context: context,
                              builder: (BuildContext context) {
                                return EmojiPicker(
                                  onEmojiSelected: (category, emoji) {
                                    setState(() {
                                      messageController.text += emoji.emoji;
                                    });
                                  },
                                  onBackspacePressed: () {
                                    setState(() {
                                      messageController.text = messageController
                                          .text.characters
                                          .skipLast(1)
                                          .toString();
                                    });
                                  },
                                  config: const Config(
                                    columns: 7,
                                    emojiSizeMax: 32.0,
                                    verticalSpacing: 0,
                                    horizontalSpacing: 0,
                                    initCategory: Category.SMILEYS,
                                  ),
                                );
                              },
                            );
                          },
                          icon: Icon(
                            Icons.emoji_emotions,
                            color: Theme.of(context)
                                .colorScheme
                                .onPrimaryContainer,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(30),
                      color: Theme.of(context).colorScheme.primary,
                    ),
                    child: IconButton(
                      onPressed: () {
                        sendMessage();
                      },
                      icon: Icon(
                        Icons.send,
                        color: Theme.of(context).colorScheme.onPrimaryContainer,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
