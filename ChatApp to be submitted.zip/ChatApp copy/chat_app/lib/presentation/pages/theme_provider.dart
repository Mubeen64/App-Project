import 'package:flutter/material.dart';

class ThemeProvider with ChangeNotifier {
  bool _isDarkMode = false;

  bool get isDarkMode => _isDarkMode;

  // Function to toggle theme
  void toggleTheme() {
    _isDarkMode = !_isDarkMode;
    // Notify listeners about the change
    notifyListeners();
  }
}
