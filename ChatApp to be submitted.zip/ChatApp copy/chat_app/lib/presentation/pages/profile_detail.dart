import 'package:flutter/material.dart';
import 'package:chat_app/models/user_model.dart';

class ProfileDetail extends StatelessWidget {
  final UserModel userModel;

  ProfileDetail({required this.userModel});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircleAvatar(
              backgroundImage: NetworkImage(userModel.profilePic.toString()),
              radius: 50,
            ),
            const SizedBox(height: 20),
            Text(
              userModel.fullname.toString(),
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Text(
              userModel.email.toString(),
              style: const TextStyle(fontSize: 15),
            ),
          ],
        ),
      ),
    );
  }
}
