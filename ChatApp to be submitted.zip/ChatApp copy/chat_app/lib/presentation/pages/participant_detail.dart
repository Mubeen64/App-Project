import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';
import 'package:chat_app/models/user_model.dart';
import 'package:chat_app/models/chat_room_model.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ParticipantDetail extends StatefulWidget {
  final UserModel targetUser;
  final ChatRoomModel chatroom;
  final User firebaseUser;
  final UserModel userModel;

  ParticipantDetail({
    Key? key,
    required this.firebaseUser,
    required this.targetUser,
    required this.chatroom,
    required this.userModel,
  }) : super(key: key);

  @override
  State<ParticipantDetail> createState() => _ParticipantDetailState();
}

class _ParticipantDetailState extends State<ParticipantDetail> {
  late DateFormat dateFormat;
  late String formattedDate;

  @override
  void initState() {
    super.initState();
    dateFormat = DateFormat('MMM d, y'); // Initialize dateFormat
    formattedDate = dateFormat.format(DateTime.now()); // Format current date
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.w),
        child: Column(
          children: [
            CircleAvatar(
              radius: 60.r,
              backgroundImage:
                  NetworkImage(widget.targetUser.profilePic.toString()),
            ),
            SizedBox(height: 24.h),
            Text(widget.targetUser.fullname.toString(),
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 25.sp,
                  color: Theme.of(context).colorScheme.secondary,
                )),
            Text(widget.targetUser.email.toString(),
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 15.sp,
                  color: Theme.of(context).colorScheme.secondary,
                )),
            SizedBox(height: 32.h),
            // Divider(),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                IconButton(
                  onPressed: () {
                    // Add call functionality
                  },
                  icon: const Icon(Icons.call),
                  color: Theme.of(context).colorScheme.secondary,
                ),
                IconButton(
                  onPressed: () {
                    // Add video call functionality
                  },
                  icon: const Icon(Icons.video_call_rounded),
                  color: Theme.of(context).colorScheme.secondary,
                ),
                IconButton(
                  onPressed: () {
                    // Add search or more info functionality
                  },
                  icon: const Icon(Icons.search),
                  color: Theme.of(context).colorScheme.secondary,
                ),
              ],
            ),
            const Divider(),
            ListTile(
              title: const Text("Available"),
              subtitle: Text(formattedDate),
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.notifications_off),
              title: const Text("Mute Notifications"),
              onTap: () {
                // Implement mute notifications
              },
            ),
            ListTile(
              leading: const Icon(Icons.music_note),
              title: const Text("Custom Notifications"),
              onTap: () {
                // Implement mute notifications
              },
            ),
            ListTile(
              leading: const Icon(Icons.browse_gallery),
              title: const Text("Media Visibility"),
              onTap: () {
                // Implement media visibility
              },
            ),
            ListTile(
              leading: const Icon(Icons.star_border),
              title: const Text("Starred Messages"),
              onTap: () {
                // Implement starred messages
              },
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.lock),
              title: const Text("Encryption"),
              onTap: () {
                // Implement encryption details or modal
              },
            ),
            ListTile(
              leading: const Icon(Icons.lock_clock),
              title: const Text("Disappearing messages"),
              onTap: () {
                // Implement mute notifications
              },
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.block, color: Colors.red),
              title: Text("Block ${widget.targetUser.fullname}"),
              onTap: () {
                // Implement block action
              },
            ),
            ListTile(
              leading: const Icon(Icons.thumb_down, color: Colors.red),
              title: Text("Report ${widget.targetUser.fullname}"),
              onTap: () {
                // Implement report action
              },
            ),
          ],
        ),
      ),
    );
  }
}
