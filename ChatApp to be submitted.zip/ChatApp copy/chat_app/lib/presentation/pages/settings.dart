import 'package:chat_app/presentation/pages/theme_provider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class SettingsPage extends StatefulWidget {
  @override
  _SettingsPageState createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  @override
  Widget build(BuildContext context) {
    // Access the theme provider
    var themeProvider = Provider.of<ThemeProvider>(context);
    String selectedLanguage = 'English';
    double fontSize = 16.0;
    String notificationPreference = 'enabled';
    String selectedTheme = 'Light';

    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            buildSection(
              'Dark Mode',
              Switch(
                value: themeProvider.isDarkMode,
                onChanged: (value) {
                  setState(() {
                    // Toggle dark mode
                    themeProvider.toggleTheme();
                  });
                },
              ),
            ),
            buildSection(
              'Push Notifications',
              Switch(
                value: true,
                onChanged: (value) {
                  setState(() {
                    // Toggle push notifications
                    // Implement your logic here
                  });
                },
              ),
            ),
            buildSection(
              'Language',
              DropdownButton<String>(
                value: selectedLanguage,
                items: ['English', 'Spanish', 'French'].map((String language) {
                  return DropdownMenuItem<String>(
                    value: language,
                    child: Text(language),
                  );
                }).toList(),
                onChanged: (String? value) {
                  setState(() {
                    selectedLanguage = value!;
                  });
                },
              ),
            ),
            buildSection(
              'Show Online Status',
              Switch(
                value: false,
                onChanged: (value) {
                  setState(() {});
                },
              ),
            ),
            buildSection(
              'Receive Newsletter',
              Switch(
                value: true,
                onChanged: (value) {
                  setState(() {});
                },
              ),
            ),
            buildSection(
              'Font Size',
              Slider(
                value: fontSize,
                min: 10,
                max: 30,
                onChanged: (value) {
                  setState(() {
                    fontSize = value;
                  });
                },
              ),
            ),
            buildSection(
              'Notification Preferences',
              Column(
                children: [
                  RadioListTile<String>(
                    title: const Text('Enabled'),
                    value: 'enabled',
                    groupValue: notificationPreference,
                    onChanged: (value) {
                      setState(() {
                        notificationPreference = value!;
                      });
                    },
                  ),
                  RadioListTile<String>(
                    title: const Text('Disabled'),
                    value: 'disabled',
                    groupValue: notificationPreference,
                    onChanged: (value) {
                      setState(() {
                        notificationPreference = value!;
                      });
                    },
                  ),
                ],
              ),
            ),
            buildSection(
              'Color Theme',
              DropdownButton<String>(
                value: selectedTheme,
                items: ['Light', 'Dark', 'System Default'].map((String theme) {
                  return DropdownMenuItem<String>(
                    value: theme,
                    child: Text(theme),
                  );
                }).toList(),
                onChanged: (String? value) {
                  setState(() {
                    selectedTheme = value!;
                  });
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildSection(String title, Widget child) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Theme.of(context).colorScheme.primary),
        ),
        const SizedBox(height: 8),
        child,
        const SizedBox(height: 20),
      ],
    );
  }
}
