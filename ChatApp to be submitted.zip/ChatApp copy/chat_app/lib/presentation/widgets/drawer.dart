import 'package:chat_app/models/user_model.dart';
import 'package:chat_app/presentation/pages/help_page.dart';
import 'package:chat_app/presentation/pages/profile_detail.dart';
import 'package:chat_app/presentation/pages/settings.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class CustomDrawer extends StatelessWidget {
  const CustomDrawer(
      {super.key, required this.userModel, required this.firebaseUser});
  final UserModel userModel;
  final User firebaseUser;

  @override
  Widget build(BuildContext context) {
    return Drawer(
        child: Column(children: [
      UserAccountsDrawerHeader(
        accountName: Text(
          userModel.fullname.toString(),
          style: const TextStyle(
              color: Colors.black, fontSize: 15, fontWeight: FontWeight.bold),
        ),
        accountEmail: Text(
          userModel.email.toString(),
          style: const TextStyle(fontSize: 15),
        ),
        currentAccountPicture: CircleAvatar(
          backgroundImage: NetworkImage(userModel.profilePic.toString()),
        ),
      ),
      ListTile(
        leading: const Icon(Icons.person_2_rounded),
        title: const Text("Profile"),
        onTap: () {
          Navigator.pop(context);
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) {
                return ProfileDetail(userModel: userModel);
              },
            ),
          );
        },
      ),
      ListTile(
        leading: const Icon(Icons.inbox),
        title: const Text("Inbox"),
        onTap: () {
          Navigator.pop(context);
        },
      ),
      ListTile(
        leading: const Icon(Icons.label_important),
        title: const Text("Important"),
        onTap: () {},
      ),
      ListTile(
        leading: const Icon(Icons.report),
        title: const Text("Spam"),
        onTap: () {},
      ),
      ListTile(
        leading: const Icon(Icons.delete),
        title: const Text("Trash"),
        onTap: () {},
      ),
      ListTile(
        leading: const Icon(Icons.markunread),
        title: const Text("Unread"),
        onTap: () {},
      ),
      ListTile(
        leading: const Icon(Icons.settings),
        title: const Text("Settings"),
        onTap: () {
          Navigator.pop(context);
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) {
                return SettingsPage();
              },
            ),
          );
        },
      ),
      ListTile(
        leading: const Icon(Icons.help),
        title: const Text("Help"),
        onTap: () {
          Navigator.pop(context);
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) {
                return HelpPage();
              },
            ),
          );
        },
      ),
    ]));
  }
}
