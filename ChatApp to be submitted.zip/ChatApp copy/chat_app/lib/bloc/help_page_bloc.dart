import 'dart:async';

class HelpBloc {
  final _emailController = StreamController<String>();
  final _messageController = StreamController<String>();
  final _formSubmitController = StreamController<void>();

  Stream<String> get emailStream => _emailController.stream;
  Stream<String> get messageStream => _messageController.stream;

  Sink<void> get formSubmitSink => _formSubmitController.sink;

  HelpBloc() {
    _formSubmitController.stream.listen((_) {
      // Handle form submission here
      final email = _emailController;
      final message = _messageController;

      // Add your logic here, for now, just print the values
      print('Email: $email, Message: $message');
    });
  }

  void dispose() {
    _emailController.close();
    _messageController.close();
    _formSubmitController.close();
  }

  void submitForm(String email, String message) {
    _emailController.add(email);
    _messageController.add(message);
    _formSubmitController.add(null);
  }
}

final helpBloc = HelpBloc();
