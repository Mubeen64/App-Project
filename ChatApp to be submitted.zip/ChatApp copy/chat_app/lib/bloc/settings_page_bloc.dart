import 'dart:async';

class SettingsBloc {
  final _darkModeController = StreamController<bool>();

  // Sink for toggling dark mode
  Function(bool) get toggleDarkMode => _darkModeController.sink.add;

  // Stream to listen to dark mode changes
  Stream<bool> get darkModeStream => _darkModeController.stream;

  // Dispose method to close the controllers
  void dispose() {
    _darkModeController.close();
  }
}
