import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:chat_app/models/firebaseHelper.dart';

// Events
abstract class HomePageEvent {}

class LoadChatRoomsEvent extends HomePageEvent {}

class DeleteChatRoomEvent extends HomePageEvent {
  final String chatRoomId;

  DeleteChatRoomEvent(this.chatRoomId);
}

// States
abstract class HomePageState {}

class HomePageLoadingState extends HomePageState {}

class HomePageLoadedState extends HomePageState {
  final List<String> selectedChatRooms;

  HomePageLoadedState(this.selectedChatRooms);
}

// BLoC
class HomePageBloc extends Bloc<HomePageEvent, HomePageState> {
  List<String> _selectedChatRooms = [];
  List<String> getSelectedChatRooms() => List.from(_selectedChatRooms);
  HomePageBloc() : super(HomePageLoadingState()) {
    on<LoadChatRoomsEvent>((event, emit) async {
      // Simulate loading chat rooms (replace with actual logic)
      await Future.delayed(Duration(seconds: 2));
      _selectedChatRooms = [
        "chatRoomId1",
        "chatRoomId2"
      ]; // Replace with actual chat room ids
      emit(HomePageLoadedState(_selectedChatRooms));
    });

    on<DeleteChatRoomEvent>((event, emit) async {
      // Simulate deletion (replace with actual logic)
      await FirebaseHelper.deleteChatRoom(
          event.chatRoomId); // Implement this function
      _selectedChatRooms.remove(event.chatRoomId);
      emit(HomePageLoadedState(List.from(_selectedChatRooms)));
    });
  }
}
