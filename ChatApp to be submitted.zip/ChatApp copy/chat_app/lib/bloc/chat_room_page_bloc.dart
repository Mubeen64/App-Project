import 'dart:async';
import 'package:bloc/bloc.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

// Events
abstract class ChatRoomPageEvent {}

class LoadMessagesEvent extends ChatRoomPageEvent {}

class SendMessageEvent extends ChatRoomPageEvent {
  final String message;

  SendMessageEvent(this.message);
}

// States
abstract class ChatRoomPageState {}

class ChatRoomPageLoadingState extends ChatRoomPageState {}

class ChatRoomPageLoadedState extends ChatRoomPageState {
  final List<String> messages;

  ChatRoomPageLoadedState(this.messages);
}

// BLoC
class ChatRoomPageBloc extends Bloc<ChatRoomPageEvent, ChatRoomPageState> {
  ChatRoomPageBloc() : super(ChatRoomPageLoadingState());

  @override
  Stream<ChatRoomPageState> mapEventToState(ChatRoomPageEvent event) async* {
    try {
      if (event is LoadMessagesEvent) {
        List<String> messages = await loadMessages(); // Load real messages
        yield ChatRoomPageLoadedState(messages);
      } else if (event is SendMessageEvent) {
        // Add logic for sending messages if needed
        // For now, we'll just reload messages after sending
        yield ChatRoomPageLoadingState();
        List<String> messages = await loadMessages();
        yield ChatRoomPageLoadedState(messages);
      }
    } catch (e) {
      yield ChatRoomPageLoadingState(); // Handle error state
    }
  }

  Future<List<String>> loadMessages() async {
    // Fetch real messages from Firebase
    QuerySnapshot snapshot = await FirebaseFirestore.instance
        .collection("chatrooms")
        .doc("YOUR_CHATROOM_ID") // Replace with your chatroom ID
        .collection("messages")
        .orderBy("createon", descending: true)
        .get();

    List<String> messages =
        snapshot.docs.map((doc) => doc["text"].toString()).toList();

    return messages;
  }
}
