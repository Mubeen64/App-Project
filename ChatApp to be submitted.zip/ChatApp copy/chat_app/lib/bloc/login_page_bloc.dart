import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:firebase_auth/firebase_auth.dart';

// Events
abstract class LoginEvent {}

class LoginWithEmailEvent extends LoginEvent {
  final String email;
  final String password;

  LoginWithEmailEvent({required this.email, required this.password});
}

class LoginWithGoogleEvent extends LoginEvent {}

// States
abstract class LoginState {}

class LoginInitial extends LoginState {}

class LoginLoading extends LoginState {}

class LoginSuccess extends LoginState {
  final User user;

  LoginSuccess({required this.user});
}

class LoginError extends LoginState {
  final String errorMessage;

  LoginError({required this.errorMessage});
}

// BLoC
class LoginBloc extends Bloc<LoginEvent, LoginState> {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  LoginBloc() : super(LoginInitial());

  @override
  Stream<LoginState> mapEventToState(LoginEvent event) async* {
    if (event is LoginWithEmailEvent) {
      yield LoginLoading();

      try {
        UserCredential userCredential = await _auth.signInWithEmailAndPassword(
          email: event.email,
          password: event.password,
        );

        yield LoginSuccess(user: userCredential.user!);
      } catch (e) {
        yield LoginError(errorMessage: e.toString());
      }
    } else if (event is LoginWithGoogleEvent) {
      yield LoginLoading();

      try {
        final GoogleSignInAccount? googleUser = await GoogleSignIn().signIn();

        if (googleUser == null) {
          // Handle the case where the Google Sign-In was canceled
          yield LoginError(errorMessage: "Google Sign-In canceled");
          return;
        }

        final GoogleSignInAuthentication? googleAuth =
            await googleUser.authentication;

        final credential = GoogleAuthProvider.credential(
          accessToken: googleAuth?.accessToken,
          idToken: googleAuth?.idToken,
        );

        UserCredential userCredential =
            await _auth.signInWithCredential(credential);

        yield LoginSuccess(user: userCredential.user!);
      } catch (e) {
        yield LoginError(errorMessage: e.toString());
      }
    }
  }
}
