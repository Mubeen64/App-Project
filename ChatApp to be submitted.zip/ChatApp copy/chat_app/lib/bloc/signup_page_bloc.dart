import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';

// Events
abstract class SignUpEvent {}

class SignUpWithEmailEvent extends SignUpEvent {
  final String email;
  final String password;

  SignUpWithEmailEvent({required this.email, required this.password});
}

class SignUpWithGoogleEvent extends SignUpEvent {}

// States
abstract class SignUpState {}

class SignUpInitial extends SignUpState {}

class SignUpLoading extends SignUpState {}

class SignUpSuccess extends SignUpState {
  final User user;

  SignUpSuccess({required this.user});
}

class SignUpError extends SignUpState {
  final String errorMessage;

  SignUpError({required this.errorMessage});
}

// BLoC
class SignUpBloc extends Bloc<SignUpEvent, SignUpState> {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  SignUpBloc() : super(SignUpInitial());

  @override
  Stream<SignUpState> mapEventToState(SignUpEvent event) async* {
    if (event is SignUpWithEmailEvent) {
      yield SignUpLoading();

      try {
        UserCredential userCredential =
            await _auth.createUserWithEmailAndPassword(
          email: event.email,
          password: event.password,
        );

        yield SignUpSuccess(user: userCredential.user!);
      } catch (e) {
        yield SignUpError(errorMessage: e.toString());
      }
    } else if (event is SignUpWithGoogleEvent) {
      yield SignUpLoading();

      try {
        final GoogleSignInAccount? googleUser = await GoogleSignIn().signIn();

        if (googleUser == null) {
          // Handle the case where the Google Sign-In was canceled
          yield SignUpError(errorMessage: "Google Sign-In canceled");
          return;
        }

        final GoogleSignInAuthentication? googleAuth =
            await googleUser.authentication;

        final credential = GoogleAuthProvider.credential(
          accessToken: googleAuth?.accessToken,
          idToken: googleAuth?.idToken,
        );

        UserCredential userCredential =
            await _auth.signInWithCredential(credential);

        yield SignUpSuccess(user: userCredential.user!);
      } catch (e) {
        yield SignUpError(errorMessage: e.toString());
      }
    }
  }
}
